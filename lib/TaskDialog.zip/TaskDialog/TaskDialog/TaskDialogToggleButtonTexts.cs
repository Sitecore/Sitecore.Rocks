﻿namespace Sid.Windows.Controls
{
    // captions for the toggle button
    public class TaskDialogToggleButtonTexts
    {
        public TaskDialogToggleButtonTexts()
        {
            ExpandText = "Show Details";
            CollapseText = "Hide Details";
        }
        public string ExpandText { get; set; }
        public string CollapseText { get; set; }
    }
}
