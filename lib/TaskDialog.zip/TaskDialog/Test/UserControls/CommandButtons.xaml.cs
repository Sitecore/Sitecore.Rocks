﻿using System.Windows;
using System.Windows.Controls;
using Sid.Windows.Controls;

namespace Test
{
    /// <summary>
    /// Interaction logic for CommandButtons.xaml
    /// </summary>
    public partial class CommandButtons : UserControl
    {

    }
}
