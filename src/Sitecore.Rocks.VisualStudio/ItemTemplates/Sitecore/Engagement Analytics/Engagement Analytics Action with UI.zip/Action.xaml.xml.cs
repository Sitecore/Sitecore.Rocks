﻿namespace $rootnamespace$
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Web;
  using Sitecore.Globalization;
  using Sitecore.Web.UI.Sheer;
  using System.Web.UI.HtmlControls;
  using Sitecore.Web.UI.HtmlControls;
  using Sitecore.Analytics.Data;
  using Sitecore.Analytics.Data.Items;
  
  public class $safeitemrootname$Editor : EditorBase
  {
    protected override void OnInit(EventArgs e)
    {
      base.OnInit(e);
    }

    protected override void OK_Click()
    {
      base.OK_Click();
    }
  }
}