namespace $rootnamespace$
{
  using Sitecore.Analytics.Data.DataAccess;
  using Sitecore.Analytics.Data.DataAccess.DataSets;
  using Sitecore.Data.Items;
  using Sitecore.Diagnostics;

  public class $safeitemname$ : AutomationAction
  {
    public override AutomationActionResult Execute(VisitorDataSet.AutomationStatesRow automationStatesRow, Item action, bool isBackgroundThread)
    {
      // insert code here
      return AutomationActionResult.Continue;
    }
  }
}