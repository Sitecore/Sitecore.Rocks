﻿namespace $rootnamespace$
{
  public class $safeitemrootname$ : Sitecore.Mvc.Presentation.RenderingModel
  {
  }
}