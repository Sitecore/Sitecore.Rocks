﻿namespace $rootnamespace$ 
{
  using System;

  public partial class $safeitemname$ : System.Web.UI.UserControl 
	{
    private void Page_Load(object sender, EventArgs e) 
    {
      // Put user code to initialize the page here
    }
  }
}