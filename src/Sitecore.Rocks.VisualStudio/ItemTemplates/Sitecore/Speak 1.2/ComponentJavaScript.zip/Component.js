﻿(function(speak) {
  speak.component({
    name: "$safeitemname$",
    initialize: function(initial, app, el, sitecore) {
    }
  });
})(Sitecore.Speak);
