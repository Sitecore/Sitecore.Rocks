﻿namespace $rootnamespace$
{
  using Sitecore.Diagnostics;
  using Sitecore.Pipelines;
  using Sitecore.Publishing.Pipelines;
  using Sitecore.Publishing.Pipelines.PublishItem;
  
  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$ : PublishItemProcessor
  {
    public override void Process(PublishItemContext context) 
    {
    }
  }
}
