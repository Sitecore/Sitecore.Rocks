﻿namespace $rootnamespace$
{
  using Sitecore.Pipelines.PreprocessRequest;
  
  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$ : PreprocessRequestProcessor
  {
    public override void Process(PreprocessRequestArgs args)
    {
    }
  }
}