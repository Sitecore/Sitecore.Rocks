﻿namespace $rootnamespace$ {

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  using Sitecore.Pipelines.GetContentEditorWarnings;
  
  public class $safeitemrootname$
  {
    public void Process([NotNull] GetContentEditorWarningsArgs args)
    {
      var warning = args.Add();

      warning.Title = "Beware";
      warning.Text = "Here be monsters.";
    }
  }
}