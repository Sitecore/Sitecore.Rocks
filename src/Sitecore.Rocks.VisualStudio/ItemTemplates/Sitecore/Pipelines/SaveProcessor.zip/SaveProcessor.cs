﻿namespace $rootnamespace$
{
  using Sitecore.Pipelines.Save;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$
  {
    public void Process([NotNull] SaveArgs args)
    {
    }
  }
}