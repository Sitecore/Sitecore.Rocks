﻿namespace $rootnamespace$
{
  using Sitecore.Pipelines.RenderLayout;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$ : RenderLayoutProcessor
  {
    public override void Process(RenderLayoutArgs args)
    {
    }
  }
}