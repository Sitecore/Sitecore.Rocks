﻿namespace $rootnamespace$
{
  using Sitecore.Pipelines.RenderField;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$
  {
    public void Process([NotNull] RenderFieldArgs args)
    {
    }
  }
}
