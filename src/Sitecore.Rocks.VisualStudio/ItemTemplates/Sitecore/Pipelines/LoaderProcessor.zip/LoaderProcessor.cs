﻿namespace $rootnamespace$
{
  using Sitecore.Diagnostics;
  using Sitecore.Pipelines;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$
  {
    public void Process(PipelineArgs args)
    {
      Log.Info("Sitecore is starting", this);
    }
  }
}