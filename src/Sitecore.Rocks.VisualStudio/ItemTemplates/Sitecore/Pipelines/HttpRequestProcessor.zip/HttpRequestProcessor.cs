﻿namespace $rootnamespace$
{
  using Sitecore.Pipelines.HttpRequest;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class.

  public class $safeitemrootname$ : HttpRequestProcessor
  {
    public override void Process(HttpRequestArgs args)
    {
    }
  }
}