﻿namespace $rootnamespace$
{
  using Sitecore.Rules;
  using Sitecore.Rules.Actions;

  // TODO: Created Sitecore Item "/sitecore/system/Settings/Rules/Common/Actions/$fileinputname$" when creating $safeitemrootname$ class. Fix Title field.

  public class $safeitemrootname$<T> : RuleAction<T> where T : RuleContext
  {
    public override void Apply([NotNull] T ruleContext)
    {
      // Execute action
    }
  }
}