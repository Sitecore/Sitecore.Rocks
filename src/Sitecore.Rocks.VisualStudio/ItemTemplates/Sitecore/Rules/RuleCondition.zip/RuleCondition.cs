﻿namespace $rootnamespace$
{
  using Sitecore.Rules;
  using Sitecore.Rules.Conditions;

  // TODO: Created Sitecore Item "/sitecore/system/Settings/Rules/Common/Conditions/$fileinputname$" when creating $safeitemrootname$ class. Fix Text field.

  public class $safeitemrootname$<T> : WhenCondition<T> where T : RuleContext
  {
    protected override bool Execute(T ruleContext)
    {
      // Return true, if the condition is satisfied.
      return false;
    }
  }
}