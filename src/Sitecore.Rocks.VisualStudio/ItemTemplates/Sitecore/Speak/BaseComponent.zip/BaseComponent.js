﻿define(["sitecore"], function (Sitecore) {
  Sitecore.Factories.createBaseComponent({
    name: "$safeitemname$",
    base: "ControlBase",
    selector: ".sc-$safeitemname$",
    attributes: [
    { name: "myProperty", value: "$el.text" }
    ]
  });
});