﻿define(["sitecore"], function (Sitecore) {
  var $safeitemname$ = Sitecore.Definitions.App.extend({
    initialized: function () {
    }
  });

  return $safeitemname$;
});