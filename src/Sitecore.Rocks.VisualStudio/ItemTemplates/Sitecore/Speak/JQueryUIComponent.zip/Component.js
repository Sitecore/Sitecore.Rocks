﻿define(['sitecore'], function (Sitecore) {
  var control = {
    componentName: "$safeitemname$",
    selector: ".sc-$safeitemname$",
    control: "$safeitemname$",

    attributes:   
    [
    ],

    events:
    [
    ],

    functions:
    [
    ],

    view:
    {
      initialized: function () {
      },
    }
  };

  Sitecore.Factories.createJQueryUIComponent(Sitecore.Definitions.Models, Sitecore.Definitions.Views, control);
});
