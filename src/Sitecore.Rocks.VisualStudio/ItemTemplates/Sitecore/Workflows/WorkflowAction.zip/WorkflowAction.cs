﻿namespace $rootnamespace$
{
  using Sitecore.Workflows.Simple;

  // TODO: To use this workflow action, create an item in your workflow based on the "Action" Template, then set Type field value to "$rootnamespace$.$safeitemrootname$,$assemblyname$"

  public class $safeitemrootname$
  {
    public void Process([NotNull] WorkflowPipelineArgs args)
    {
    }
  }
}