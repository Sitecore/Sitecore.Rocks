﻿namespace Sitecore 
{
  public class Generator 
  {
    public string Execute() 
    {
      return "Hello World";
    }
  }
}