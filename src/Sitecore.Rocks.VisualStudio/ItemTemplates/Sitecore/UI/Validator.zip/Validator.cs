﻿namespace $rootnamespace$
{
  using System;
  using System.Runtime.Serialization;
  using Sitecore.Data.Validators;

  // TODO: Automatically created Item in Master database "/sitecore/system/Settings/Validation Rules/Item Rules/$fileinputname$" when creating $safeitemrootname$ class. 

  [Serializable]
  public class $safeitemrootname$ : StandardValidator
  {
    public $safeitemrootname$()
    {
    }

    public $safeitemrootname$(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }

    public override string Name
    {
      get
      {
        return "Validator Name";
      }
    }

    protected override ValidatorResult Evaluate()
    {
      var item = this.GetItem();
      if (item == null)
      {
        return ValidatorResult.Valid;
      }

      this.Text = this.GetText("The item \"{0}\" has errors.", item.DisplayName);
      return this.GetFailedResult(ValidatorResult.Error);
    }

    protected override ValidatorResult GetMaxValidatorResult()
    {
      return this.GetFailedResult(ValidatorResult.Error);
    }
  }
}