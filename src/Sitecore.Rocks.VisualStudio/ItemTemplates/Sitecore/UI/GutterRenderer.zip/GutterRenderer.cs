﻿namespace $rootnamespace$
{
  using Sitecore.Data.Items;
  using Sitecore.Shell.Applications.ContentEditor.Gutters;

  // TODO: Created Sitecore Item in core database "/sitecore/content/Applications/Content Editor/Gutters/$fileinputname$" when creating $safeitemrootname$ class. Fix Header field.

  public class $safeitemrootname$ : GutterRenderer
  {
    protected override GutterIconDescriptor GetIconDescriptor(Item item)
    {
      var descriptor = new GutterIconDescriptor
      {
        Icon = "Network/16x16/lock.png",
        Tooltip = "Custom gutter renderer"
      };

      return descriptor;
    }
  }
}