﻿namespace $rootnamespace$
{
  using Sitecore.Data;
  using Sitecore.Data.Items;
  using Sitecore.Diagnostics;
  using Sitecore.Shell.Framework.Commands;

  // TODO: \App_Config\include\$fileinputname$.config created automatically when creating $safeitemrootname$ class. In this config include file, specify command name attribute value

  public class $safeitemrootname$ : Command
  {
    public override void Execute([NotNull] CommandContext context)
    {
    }
  }
}