﻿/*
 * 1. Implement this comparing logic in this file.
 */
namespace $rootnamespace$
{
  using Sitecore.Data.Comparers;
  using Sitecore.Data.Items;

  // TODO: Automatically created Item in Master database "/sitecore/system/Settings/Subitems Sorting/$fileinputname$" when creating $safeitemrootname$ class. 

  public class $safeitemrootname$ : Comparer 
  {
    protected override int DoCompare(Item item1, Item item2) 
    {
      // Change this logic
      return item1.Name.CompareTo(item1.Name);
    }
  }
}