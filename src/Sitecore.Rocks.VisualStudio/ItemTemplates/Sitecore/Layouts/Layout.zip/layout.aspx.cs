namespace $rootnamespace$
{
  using System;
  using System.Web;
  using System.Web.UI;

  public partial class $safeitemname$ : Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
		}
	}
}
