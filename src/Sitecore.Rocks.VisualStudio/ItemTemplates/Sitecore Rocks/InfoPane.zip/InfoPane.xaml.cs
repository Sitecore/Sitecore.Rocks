﻿namespace $rootnamespace$
{
  using System;
  using System.Collections.Generic;
  using System.Linq;
  using System.Windows;
  using System.Windows.Controls;
  using System.Windows.Input;
  using System.Windows.Media;
  using Sitecore.VisualStudio.Annotations;
  using Sitecore.VisualStudio.ContentEditors.Commands.Tasks;
  using Sitecore.VisualStudio.Data;
  using Sitecore.VisualStudio.Diagnostics;
  using Sitecore.VisualStudio.ContentEditors.InfoPanes;
  using Sitecore.VisualStudio.ContentEditors;

  [InfoPane("MyInfoPane", 5000)]
  public partial class $safeitemname$ : IInfoPane
  {
    public $safeitemname$()
    {
      this.InitializeComponent();
    }

    protected ContentEditor ContentEditor { get; set; }

    public bool CanRender(ContentEditor contentEditor)
    {
      var contentModel = contentEditor.ContentModel;

      if (contentModel.IsEmpty)
      {
        return false;
      }

      return true;
    }

    public object GetHeader()
    {
      var icon = new Icon("Resources/16x16/home.png");

      var image = new Image
      {
        Source = icon.GetSource(), SnapsToDevicePixels = true, Width = 16, Height = 16
      };

      RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.NearestNeighbor);

      return image;
    }

    public FrameworkElement Render(ContentEditor contentEditor)
    {
      return this;
    }
  }
}