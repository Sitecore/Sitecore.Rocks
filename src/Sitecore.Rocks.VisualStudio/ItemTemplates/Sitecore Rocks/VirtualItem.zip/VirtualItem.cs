namespace $rootnamespace$
{
  using System.Linq;
  using Sitecore.VisualStudio.ContentTrees.Items;
  using Sitecore.VisualStudio.ContentTrees.VirtualItems;

  [VirtualItem(1000)]
  public class $safeitemname$ : IVirtualItem
  {
    public bool CanAddItem(BaseTreeViewItem parent)
    {
      // Return true, if the item can be added to this parent
      return parent == null;
    }

    public BaseTreeViewItem GetItem(BaseTreeViewItem parent)
    {
      // Create the tree view item and make it expandable
      var result = new MyTreeViewItem();
      result.MakeExpandable();

      return result;
    }

    // tree view item stub
    public class MyTreeViewItem : BaseTreeViewItem
    {
      public MyTreeViewItem()
      {
        this.Text = "$safeitemname$";
        this.Icon = new Icon("Resources/16x16/document.png");
      }

      public override bool GetChildren(GetChildrenDelegate callback, bool async)
      {
        callback(Enumerable.Empty<BaseTreeViewItem>());
        return false;
      }
    }
  }
}