namespace $rootnamespace$
{
  using Sitecore.VisualStudio.Diagnostics;
  using Sitecore.VisualStudio.Extensibility.Pipelines;
  using Sitecore.VisualStudio.ContentEditors.Pipelines.LoadItems;

  [Pipeline(typeof(LoadItemsPipeline), 5000)]
  public class GetContentModel : PipelineProcessor<LoadItemsPipeline>
  {
    protected override void Process(LoadItemsPipeline pipeline)
    {
    }
  }
}