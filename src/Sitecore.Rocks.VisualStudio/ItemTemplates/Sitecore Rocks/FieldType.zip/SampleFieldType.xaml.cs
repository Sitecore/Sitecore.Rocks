﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="$safeitemname$.xaml.cs" company="Sitecore A/S">
//   Copyright (C) 2010 by Sitecore A/S
// </copyright>
// <summary>
//   Interaction logic for CheckBoxField.xaml
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.VisualStudio.Samples
{
  using System.Windows.Controls;
  using Sitecore.VisualStudio.Annotations;
  using Sitecore.VisualStudio.ContentEditors;
  using Sitecore.VisualStudio.Data;
  using Sitecore.VisualStudio.Diagnostics;

  /// <summary>Interaction logic for CheckBoxField.xaml</summary>
  /// <remarks>A field control is marked with the FieldControl attribute and implements the IFieldControl interface.
  /// The type name parameter of the FieldControl attribute must match a Sitecore field type identifier,
  /// e.g. "Single-Line Text" or "Rich Text".</remarks>
  [FieldControl("samplefieldtype")]
  public partial class $safeitemname$ : IFieldControl
  {
    #region Constructors and Destructors

    /// <summary>
    /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
    /// </summary>
    public $safeitemname$()
    {
      this.InitializeComponent();
    }

    #endregion

    #region Events

    /// <summary>Raised when the field changes value.</summary>
    /// <remarks>The Content Editor becomes modified when raised.</remarks>
    public event ValueModifiedEventHandler ValueModified;

    #endregion

    #region Implemented Interfaces

    #region IFieldControl

    /// <summary>Gets the focusable control.</summary>
    /// <returns>Returns a control the can receice focus.</returns>
    public Control GetFocusableControl()
    {
      return this;
    }

    /// <summary>Gets the value of the field.</summary>
    /// <returns>Returns the value.</returns>
    [NotNull]
    public string GetValue()
    {
      return string.Empty;
    }

    /// <summary>Determines whether the specified source field is supported.</summary>
    /// <param name="sourceField">The source field.</param>
    /// <returns><c>True</c>, if the field is supported, otherwise <c>False</c>.</returns>
    public bool IsSupported([NotNull] Field sourceField)
    {
      Assert.ArgumentNotNull(sourceField, "sourceField");

      return true;
    }

    /// <summary>Sets the field.</summary>
    /// <remarks>This is called before the SetValue method when an item is loaded into the Content Editor.</remarks>
    /// <param name="sourceField">The field.</param>
    public void SetField(Field sourceField)
    {
      Assert.ArgumentNotNull(sourceField, "sourceField");
    }

    /// <summary>Sets the value.</summary>
    /// <remarks>The value may be set by actions in the system, e.g. when the user uses the Edit Externally command.</remarks>
    /// <param name="value">The value.</param>
    public void SetValue([NotNull] string value)
    {
      Assert.ArgumentNotNull(value, "value");
    }

    /// <summary>Gets the control.</summary>
    /// <returns>Returns the control.</returns>
    public Control GetControl()
    {
      return this;
    }

    #endregion

    #endregion
  }
}