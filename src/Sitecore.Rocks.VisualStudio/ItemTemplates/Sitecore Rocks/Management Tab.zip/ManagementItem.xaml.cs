﻿namespace $rootnamespace$
{
  using System.Windows;
  using Sitecore.VisualStudio.UI.Management;

  [Management("$safeitemname$", 1000)]
  public partial class $safeitemname$ : IManagementItem
  {
    public $safeitemname$()
    {
      InitializeComponent();
    }

    public SiteManagementContext Context { get; protected set; }

    public bool CanExecute(IManagementContext context)
    {
      // context can be SiteManagementContext or DatabaseManagementContext
      return context is SiteManagementContext;
    }

    public UIElement GetControl(IManagementContext context)
    {
      this.Context = (SiteManagementContext)context;
      return this;
    }
  }
}
