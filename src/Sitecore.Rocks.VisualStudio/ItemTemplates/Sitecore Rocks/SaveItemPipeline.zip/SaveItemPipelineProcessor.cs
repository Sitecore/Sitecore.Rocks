namespace $rootnamespace$
{
  using System;
  using Sitecore.VisualStudio.Annotations;
  using Sitecore.VisualStudio.Data;
  using Sitecore.VisualStudio.Data.DataServices;
  using Sitecore.VisualStudio.Diagnostics;
  using Sitecore.VisualStudio.Extensibility.Pipelines;
  using Sitecore.VisualStudio.ContentEditors.Pipelines.SaveItem;

  [Pipeline(typeof(SaveItemPipeline), 5000)]
  public class SaveItem : PipelineProcessor<SaveItemPipeline>
  {
    protected override void Process([NotNull] SaveItemPipeline pipeline)
    {
    }
  }
}