namespace $rootnamespace$
{
  using System.Linq;
  using Sitecore.VisualStudio.ContentTrees.Items;
  using Sitecore.VisualStudio.Data;

  public class $safeitemname$ : BaseTreeViewItem
  {
    public $safeitemname$()
    {
      this.Text = "$safeitemname$";
      this.Icon = new Icon("Resources/16x16/document.png");
    }

    public override bool GetChildren(GetChildrenDelegate callback, bool async)
    {
      // build a list of tree view items and invoke the call back method
      callback(Enumerable.Empty<BaseTreeViewItem>());

      // if async == false, the method must not return until the items have 
      // been added to the tree view.

      // Return false, if the operation failed
      return true;
    }
  }
}