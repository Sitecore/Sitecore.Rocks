namespace $rootnamespace$
{
  using Sitecore.VisualStudio.Applications;
  using Sitecore.VisualStudio.Commands;
  using Sitecore.VisualStudio.ContentTrees;

  [Command]
  public class $safeitemname$ : CommandBase
  {
    public $safeitemname$()
    {
      this.Text = "Open $saferootname$";
      this.Group = "My Group of Commands";
      this.SortingValue = 1000;
    }

    public override bool CanExecute(object parameter)
    {
      var context = parameter as ContentTreeContext;
      if (context == null)
      {
        return false;
      }

      return true;
    }

    public override void Execute(object parameter)
    {
      var context = parameter as ContentTreeContext;
      if (context == null)
      {
        return;
      }
      
      var documentWindow = SitecoreApplication.Instance.WindowFactory.OpenDocument<$saferootname$>("$saferootname$");
    }
  }
}