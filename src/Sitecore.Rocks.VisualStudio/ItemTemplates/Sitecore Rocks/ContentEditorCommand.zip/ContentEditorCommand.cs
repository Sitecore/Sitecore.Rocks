namespace $rootnamespace$
{
  using Sitecore.VisualStudio.Commands;
  using Sitecore.VisualStudio.ContentEditors;

  /// <summary>Defines the content tree command class.</summary>
  [Command]
  public class $safeitemname$ : CommandBase
  {
    #region Constructors and Destructors

    /// <summary>
    /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
    /// </summary>
    public $safeitemname$()
    {
      this.Text = "My Command";
      this.Group = "My Group of Commands";
      this.SortingValue = 1000;
    }

    #endregion

    #region Public Methods

    /// <summary>Defines the method that determines whether the command can execute in its current state.</summary>
    /// <param name="parameter">Data used by the command.  If the command does not require data to be passed, this object can be set to null.</param>
    /// <returns>true if this command can be executed; otherwise, false.</returns>
    public override bool CanExecute(object parameter)
    {
      var context = parameter as ContentEditorContext;
      if (context == null)
      {
        return false;
      }

      return true;
    }

    /// <summary>Executes the command.</summary>
    /// <param name="parameter">The parameter.</param>
    public override void Execute(object parameter)
    {
      var context = parameter as ContentEditorContext;
      if (context == null)
      {
        return;
      }
    }

    #endregion
  }
}