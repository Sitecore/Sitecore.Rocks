namespace $rootnamespace$
{
  using Sitecore.VisualStudio.Diagnostics;
  using Sitecore.VisualStudio.Extensibility.Pipelines;
  using Sitecore.VisualStudio.ContentEditors.Pipelines.SetFieldVisibility;

  [Pipeline(typeof(SetFieldVisibilityPipeline), 5000)]
  public class StandardFields : PipelineProcessor<SetFieldVisibilityPipeline>
  {
    protected override void Process(SetFieldVisibilityPipeline pipeline)
    {
    }
  }
}