﻿namespace Sitecore.VisualStudio.Samples
{
  using System.Windows;
  using System.Windows.Controls;
  using Sitecore.VisualStudio.Annotations;
  using Sitecore.VisualStudio.ContentEditors;
  using Sitecore.VisualStudio.ContentEditors.Panes;
  using Sitecore.VisualStudio.ContentEditors.Skins;
  using Sitecore.VisualStudio.ContentEditors.Skins.Default;
  using Sitecore.VisualStudio.ContentEditors.Validators;
  using Sitecore.VisualStudio.Data;
  using Sitecore.VisualStudio.Diagnostics;
  using Sitecore.VisualStudio.Sites;

  /// <summary>Defines the sample skin class.</summary>
  [Skin("Sample")]
  public partial class $safeitemname$ : ISkin
  {
    #region Constructors and Destructors

    /// <summary>
    /// Initializes a new instance of the <see cref="$safeitemname$"/> class.
    /// </summary>
    public $safeitemname$()
    {
      this.InitializeComponent();
    }

    #endregion

    #region Implemented Interfaces

    #region ISkin

    /// <summary>
    /// Gets or sets the content editor.
    /// </summary>
    /// <value>The content editor.</value>
    public ContentEditor ContentEditor { get; set; }

    /// <summary>
    /// Gets or sets the content model.
    /// </summary>
    /// <value>The content model.</value>
    public ContentModel ContentModel { get; set; }

    #endregion

    #endregion

    #region Properties

    /// <summary>
    /// Gets or sets the site.
    /// </summary>
    /// <value>The site.</value>
    public Site Site { get; set; }

    #endregion

    #region Implemented Interfaces

    #region ISkin

    /// <summary>Gets the control.</summary>
    /// <returns>Returns the control.</returns>
    [NotNull]
    public Control GetControl()
    {
      return this;
    }

    /// <summary>Gets the validate bar.</summary>
    /// <returns>Returns the validate bar.</returns>
    public ValidatorBar GetValidatorBar()
    {
      return this.ValidatorBar;
    }

    /// <summary>Renders the fieldss.</summary>
    /// <returns>Returns the first focusable control.</returns>
    [CanBeNull]
    public Control RenderFields()
    {
      Control result = null;

      this.QuickInfo.Load(this.ContentEditor);
      this.ContentEditorWarnings.Load(this.ContentModel);

      this.Tabs.Items.Clear();

      if (this.ContentModel.IsSingle && this.ContentModel.FirstItem.Versions.Count == 0)
      {
        var tabItem = new TabItem
        {
          Header = "Fields"
        };

        this.Tabs.Items.Add(tabItem);

        tabItem.Content = new NoVersionsPane();

        return null;
      }

      string sectionName = null;

      StackPanel sectionControl = null;

      foreach (var field in this.ContentModel.Fields)
      {
        if (!this.ContentModel.CanShowField(field))
        {
          continue;
        }

        if (field.Section.Name != sectionName)
        {
          sectionName = field.Section.Name;

          sectionControl = new StackPanel();

          var scrollViewer = new ScrollViewer();

          var tabItem = new TabItem
          {
            Header = sectionName
          };

          scrollViewer.Content = sectionControl;
          tabItem.Content = scrollViewer;
          this.Tabs.Items.Add(tabItem);
        }

        if (sectionControl == null)
        {
          continue;
        }

        this.RenderLabel(sectionControl, field);
        var control = this.RenderControl(sectionControl, field);
        if (result == null)
        {
          result = control;
        }
      }

      if (sectionName == null)
      {
        this.RenderNoFields();
      }

      return result;
    }

    #endregion

    #endregion

    #region Methods

    /// <summary>Renders the control.</summary>
    /// <param name="section">The section.</param>
    /// <param name="field">The field.</param>
    /// <returns>Returns the control.</returns>
    [NotNull]
    private Control RenderControl([NotNull] StackPanel section, [NotNull] Field field)
    {
      Assert.ArgumentNotNull(section, "section");
      Assert.ArgumentNotNull(field, "field");

      var control = field.Control.GetControl();
      control.BorderThickness = new Thickness(1);

      var border = new FieldBorder
      {
        FieldControl = control
      };

      section.Children.Add(border);

      var result = field.Control.GetFocusableControl();
      if (result == null)
      {
        result = control;
      }

      return result;
    }

    /// <summary>Renders the label.</summary>
    /// <param name="section">The section.</param>
    /// <param name="field">The field.</param>
    private void RenderLabel([NotNull] StackPanel section, [NotNull] Field field)
    {
      Assert.ArgumentNotNull(section, "section");
      Assert.ArgumentNotNull(field, "field");

      var label = new ContentEditors.Skins.Default.Label
      {
        ContentEditor = this.ContentEditor, 
        Field = field
      };

      section.Children.Add(label);
    }

    /// <summary>Renders the No Fields pane.</summary>
    private void RenderNoFields()
    {
      var tabItem = new TabItem
      {
        Header = "Fields"
      };

      this.Tabs.Items.Add(tabItem);

      tabItem.Content = new NoFieldsPane();
    }

    #endregion
  }
}