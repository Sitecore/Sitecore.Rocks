namespace $safeprojectname$.Commands
{
  using Sitecore.VisualStudio.Commands;
  using Sitecore.VisualStudio.ContentTrees;

  [Command]
  public class SitecoreExplorerCommand1 : CommandBase
  {
    public ContentTreeCommand1()
    {
      this.Text = "My Command";
      this.Group = "My Group of Commands";
      this.SortingValue = 1000;
    }
    public override bool CanExecute(object parameter)
    {
      var context = parameter as ContentTreeContext;
      if (context == null)
      {
        return false;
      }

      return true;
    }
    
    public override void Execute(object parameter)
    {
      var context = parameter as ContentTreeContext;
      if (context == null)
      {
        return;
      }

      // Execute command code here.
    }
  }
}